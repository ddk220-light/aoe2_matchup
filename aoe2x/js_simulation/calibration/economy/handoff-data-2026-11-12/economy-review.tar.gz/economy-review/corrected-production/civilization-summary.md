# Civilization production review — first pass

User-supplied DAT snapshot; fully researched Imperial. All numbers and modifier rules come from that source. Matching shipped tech trees supply availability and labels when present. The advisor roster supplies comparison coverage only.

Building ranking: wood + 2 × stone. All alternatives remain in the database. Rows with review flags are provisional.

The broader source inventory is a candidate list: availability gates may over-include conditional or ally-granted units. Source-only candidates are marked below for owner review.

## Armenians

18 advisor roster units; 18 times calculated; 1 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Aztecs

15 advisor roster units; 15 times calculated; 1 rows flagged. Separately, 23 unit groups resolved from the source, including economic units.

- **Aztecs Tech Tree** (effect 447): unit training time multiply 0.869565; buildings: Archery Range, Barracks, Castle, Dock, Siege Workshop; units/candidates: Arbalester, Carrack, Catapult Galleon, Champion, Demo Ship, Demolition Ship, Elite Eagle Warrior, Elite Jaguar Warrior, Elite Skirmisher, Fast Fire Ship, Petard, Pikeman, Scorpion, Siege Onager, Siege Ram, Siege Tower, Trebuchet, Trebuchet (Packed), War Galley.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Bengalis

18 advisor roster units; 18 times calculated; 2 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `unit_availability_needs_review`: Elite Ratha (Melee).
- `unit_not_resolved_as_trainable_in_final_source_state`: Elite Ratha (Melee).

## Berbers

22 advisor roster units; 22 times calculated; 2 rows flagged. Separately, 29 unit groups resolved from the source, including economic units.

- **Kasbah** (effect 607): production building work rate multiply 1.25; buildings: Castle; units/candidates: Elite Camel Archer, Petard, Trebuchet, Trebuchet (Packed).

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `unit_availability_needs_review`: Xebec.
- `unit_not_resolved_as_trainable_in_final_source_state`: Xebec.

## Bohemians

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

- **Bohemians Team Bonus** (effect 804): production building work rate multiply 1.8; buildings: Market; units/candidates: Trade Cart.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Britons

17 advisor roster units; 17 times calculated; 1 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **C-Bonus, 1/2 TCs** (effect 379): building cost multiply 0.5; buildings: Town Center; units/candidates: Villager.
- **Britons Team Bonus** (effect 399): production building work rate multiply 1.1; buildings: Archery Range; units/candidates: Arbalester, Elite Skirmisher, Heavy Mounted Crossbowman.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Bulgarians

17 advisor roster units; 17 times calculated; 1 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **C-Bonus, TC Cost 1/2 Stone** (effect 731): building cost multiply 0.5; buildings: Town Center; units/candidates: Villager.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Cheapest alternate-building selections:

- Elite Konnik: Krepost, 700.00 wood-equivalent, 12.03s.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Burgundians

20 advisor roster units; 20 times calculated; 2 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `special_production_or_transformation_effect_review`: Flemish Militia.

## Burmese

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Byzantines

21 advisor roster units; 21 times calculated; 1 rows flagged. Separately, 29 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Celts

17 advisor roster units; 17 times calculated; 1 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **Celts Team Bonus** (effect 401): production building work rate multiply 1.2; buildings: Siege Workshop; units/candidates: Heavy Scorpion, Siege Onager, Siege Ram, Siege Tower.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Chinese

18 advisor roster units; 18 times calculated; 2 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Dragon Ship, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `unit_availability_needs_review`: Fire Ship.
- `unit_not_resolved_as_trainable_in_final_source_state`: Fire Ship.

## Cumans

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

- **C-Bonus, Cheap Ranges and Stables** (effect 697): building cost add -75; buildings: Archery Range, Stable; units/candidates: Camel Rider, Crossbowman, Elite Skirmisher, Elite Steppe Lancer, Heavy Cavalry Archer, Hussar, Paladin.
- **Steppe Husbandry** (effect 726): unit training time multiply 0.5; buildings: Archery Range, Stable; units/candidates: Elite Steppe Lancer, Heavy Cavalry Archer, Hussar.

Source-only candidates (availability needs review): Elite Kipchak, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Danes

18 advisor roster units; 18 times calculated; 1 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Dravidians

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Ethiopians

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Franks

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

- **C-Bonus, Castle 15% cheaper** (effect 324): building cost multiply 0.85; buildings: Castle; units/candidates: Elite Throwing Axeman, Petard, Trebuchet, Trebuchet (Packed).
- **C-Bonus, Castle 25% cheaper** (effect 329): building cost multiply 0.882353; buildings: Castle; units/candidates: Elite Throwing Axeman, Petard, Trebuchet, Trebuchet (Packed).
- **Chivalry** (effect 548): production building work rate multiply 1.4; buildings: Stable; units/candidates: Light Cavalry, Paladin.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Georgians

18 advisor roster units; 18 times calculated; 1 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Goths

19 advisor roster units; 19 times calculated; 2 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

- **Goths Team Bonus** (effect 405): production building work rate multiply 1.2; buildings: Barracks; units/candidates: Champion, Elite Huskarl, Halberdier.
- **Anarchy** (effect 462): production location set 12; buildings: Barracks; units/candidates: Elite Huskarl.
- **Perfusion** (effect 513): production building work rate multiply 2; buildings: Barracks; units/candidates: Champion, Elite Huskarl, Halberdier.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Cheapest alternate-building selections:

- Elite Huskarl: Barracks, 175.00 wood-equivalent, 5.01s.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Elite Huskarl.

## Gurjaras

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

- **Gurjaras Team Bonus** (effect 843): unit training time multiply 0.8; buildings: Archery Range, Siege Workshop, Stable; units/candidates: Elite Elephant Archer, Heavy Camel Rider, Siege Elephant.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Hindustanis

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Huns

17 advisor roster units; 17 times calculated; 2 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **Huns Team Bonus** (effect 484): production building work rate multiply 1.2; buildings: Stable; units/candidates: Elite Tarkan, Hussar, Paladin.
- **Marauders** (effect 538): production location set 101; buildings: Stable; units/candidates: Elite Tarkan.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Cheapest alternate-building selections:

- Elite Tarkan: Stable, 175.00 wood-equivalent, 15.04s.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Elite Tarkan.

## Incas

15 advisor roster units; 15 times calculated; 1 rows flagged. Separately, 23 unit groups resolved from the source, including economic units.

- **C-Bonus, TC Stone cost** (effect 171): building cost multiply 0.85; buildings: Town Center; units/candidates: Villager.
- **C-Bonus, Building Stone cost** (effect 575): building cost multiply 0.85; buildings: Castle, Town Center; units/candidates: Elite Kamayuk, Petard, Trebuchet, Trebuchet (Packed), Villager.
- **C-Bonus, Building Stone cost** (effect 575): building cost multiply 1.17647; buildings: Town Center; units/candidates: Villager.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Italians

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Japanese

18 advisor roster units; 18 times calculated; 1 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Jurchens

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Khitans

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

- **C-Bonus, Skirms Spear Scout train 25% faster** (effect 1011): unit training time multiply 0.869565; buildings: Archery Range, Barracks, Stable; units/candidates: Elite Skirmisher, Hussar, Pikeman.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Khmer

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Koreans

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Lithuanians

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

- **Lithuanians Team Bonus** (effect 713): production building work rate multiply 1.2; buildings: Monastery; units/candidates: Monk.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Magyars

17 advisor roster units; 17 times calculated; 1 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **Magyars Team Bonus** (effect 6): unit training time multiply 0.8; buildings: Archery Range; units/candidates: Heavy Cavalry Archer.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Malay

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Malians

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

- **C-Bonus, TC Wood cost** (effect 165): building cost multiply 0.85; buildings: Town Center; units/candidates: Villager.
- **C-Bonus, buildings cost -15% w** (effect 617): building cost multiply 0.85; buildings: Archery Range, Barracks, Dock, Market, Monastery, Siege Workshop, Stable, Town Center; units/candidates: Arbalester, Bombard Cannon, Cannon Galleon, Capped Ram, Carrack, Cavalier, Champion, Elite Skirmisher, Fast Fire Ship, Fishing Ship, Hand Cannoneer, Heavy Camel Rider, Heavy Cavalry Archer, Heavy Demo Ship, Heavy Demolition Ship, Light Cavalry, Monk, Pikeman, Scorpion, Siege Onager, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Villager, War Galley.
- **C-Bonus, buildings cost -15% w** (effect 617): building cost multiply 1.17647; buildings: Town Center; units/candidates: Villager.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Mapuche

16 advisor roster units; 16 times calculated; 1 rows flagged. Separately, 24 unit groups resolved from the source, including economic units.

- **C-Bonus, Skirms Spear Settlements** (effect 1382): production button set 1; buildings: SETTL1; units/candidates: Elite Skirmisher.
- **C-Bonus, Skirms Spear Settlements** (effect 1382): production location set 2556; buildings: SETTL1; units/candidates: Elite Skirmisher, Halberdier.
- **C-Bonus, Skirms Spear Settlements train time1** (effect 1405): unit training time multiply 2.15; buildings: SETTL1; units/candidates: Elite Skirmisher, Halberdier.
- **C-Bonus, Skirms Spear Settlements train time2** (effect 1406): unit training time multiply 0.75; buildings: SETTL1; units/candidates: Elite Skirmisher, Halberdier.
- **C-Bonus, Skirms Spear Settlements train time3** (effect 1407): unit training time multiply 0.6202; buildings: SETTL1; units/candidates: Elite Skirmisher, Halberdier.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Mayans

15 advisor roster units; 15 times calculated; 1 rows flagged. Separately, 23 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Mongols

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Muisca

16 advisor roster units; 16 times calculated; 2 rows flagged. Separately, 24 unit groups resolved from the source, including economic units.

- **Huaracas** (effect 1366): unit training time multiply 0.666667; buildings: Archery Range; units/candidates: Slinger.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Cheapest alternate-building selections:

- Elite Temple Guard: Monastery, 175.00 wood-equivalent, 18.00s.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Elite Temple Guard.

## Persians

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

- **C-Bonus, TC and Dock work rate** (effect 421): production building work rate multiply 1.05; buildings: Dock, Town Center; units/candidates: Carrack, Elite Cannon Galleon, Fast Fire Ship, Fishing Ship, Galleon, Heavy Demo Ship, Heavy Demolition Ship, Trade Cog, Transport Ship, Villager.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Poles

18 advisor roster units; 18 times calculated; 1 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Portuguese

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

- **Circumnavigation** (effect 1404): unit training time multiply 0.75; buildings: Dock; units/candidates: Carrack, Elite Cannon Galleon, Elite Caravel, Fire Ship, Fishing Ship, Galleon, Trade Cog, Transport Ship.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Romans

17 advisor roster units; 17 times calculated; 1 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **Comitatenses** (effect 895): unit training time multiply 0.666667; buildings: Barracks, Castle, Stable; units/candidates: Cavalier, Elite Centurion, Legionary.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Saracens

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

- **C-Bonus, Market** (effect 354): building cost add -100; buildings: Market; units/candidates: Trade Cart.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Saxons

18 advisor roster units; 18 times calculated; 1 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

- **Clerical Recruitment** (effect 1491): unit training time multiply 0.75; buildings: Monastery; units/candidates: Monk.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Shu

17 advisor roster units; 17 times calculated; 0 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Liu Bei, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Villager.

## Sicilians

17 advisor roster units; 17 times calculated; 1 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Cheapest alternate-building selections:

- Elite Serjeant: Donjon, 400.00 wood-equivalent, 9.02s.
- Halberdier: Barracks, 175.00 wood-equivalent, 16.54s.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Slavs

17 advisor roster units; 17 times calculated; 1 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **Detinets** (effect 481): building cost add -260; buildings: Castle; units/candidates: Elite Boyar, Petard, Trebuchet, Trebuchet (Packed).
- **Detinets** (effect 481): building cost add 260; buildings: Castle; units/candidates: Elite Boyar, Petard, Trebuchet, Trebuchet (Packed).

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Spanish

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Missionary, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Tatars

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 29 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Flaming Camel, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Teutons

19 advisor roster units; 19 times calculated; 1 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Tupi

16 advisor roster units; 16 times calculated; 1 rows flagged. Separately, 24 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Turks

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

- **Turks Team Bonus** (effect 410): unit training time multiply 0.8; buildings: Archery Range, Castle, Dock, Siege Workshop; units/candidates: Bombard Cannon, Elite Cannon Galleon, Elite Janissary, Hand Cannoneer.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Varangians

18 advisor roster units; 18 times calculated; 1 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Vietnamese

20 advisor roster units; 20 times calculated; 1 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Vikings

18 advisor roster units; 18 times calculated; 1 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

- **Vikings Team Bonus** (effect 411): building cost multiply 0.85; buildings: Dock; units/candidates: Carrack, Catapult Galleon, Elite Longship, Fire Ship, Fishing Ship, Galleon, Trade Cog, Transport Ship.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet (Packed), Villager.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.

## Wei

17 advisor roster units; 17 times calculated; 0 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Cao Cao, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Villager.

## Wu

18 advisor roster units; 18 times calculated; 0 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Fishing Ship, Monk, Petard, Siege Tower, Sun Jian, Trade Cart, Trade Cog, Transport Ship, Villager.

