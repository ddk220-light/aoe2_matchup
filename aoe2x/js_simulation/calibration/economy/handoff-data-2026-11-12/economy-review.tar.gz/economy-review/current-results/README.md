# Post-Imperial economy review

Source: the user's empires2_x2_p1.dat and matching Civilization Tech Tree files,
with exact paths/checksums in manifest.json. No external game-information source
was used. The review covers all 56 civilizations and the 1,030 advisor entries.

This is a source-parameter inventory and funding-demand calculation. It is not
yet a calibrated model of resources deposited by an economy on a particular map.

## What is recorded

- civilization-parameters.csv: final work rates, task resource multipliers,
  movement, raw carrying capacity, farm availability, food capacity and wood cost.
- economic-technologies.csv: available/missing technologies, costs, free/instant
  status and the kind of economic or worker-survival connection. A technology
  can be available without having an economic effect for that civilization.
- economic-actors.csv: workers, fishing/trade units, farms and infrastructure,
  with base/final values, population-storage values and modifier provenance.
- gather-tasks.csv: raw task targets, output resources and player-resource links.
  Secondary-income and trade task semantics are left explicitly unresolved.
- economic-effects.csv and resource-parameters.csv: source commands, including
  special player-level economic parameters and engine calculation hooks.
- activation-exclusions.csv: inaccessible hidden/team/campaign technologies that
  must not be activated merely because their prerequisites are satisfied.
- unit-funding-demand.csv: final unit cost and resource flow per game minute for
  one continuously training building. Farm maintenance is not added to this table.
- production-corrections.csv: corrections to 35 naval entries in the preceding
  production draft, caused by an incorrectly activated Shipwright variant.
- economy-source-review.sqlite: the same data in queryable tables.

## Distinctions that matter

1. Work rate and delivered income are different. Effective income also depends
   on walking, cargo size/rounding, drop-off, congestion, target switching, stock
   availability and special mechanics. A nominal work product is not a promised
   per-villager income rate.
2. Free or discounted research saves setup resources/time. Once both sides have
   the same upgrade, the final modifier is applied once, with no extra ongoing
   gather bonus because it was free. Missing upgrades still affect final output.
3. Farm food capacity primarily reduces reseeding frequency and wood upkeep.
   Farmer work rate, the farm's own work rate, cargo and walking are separate.
   Khmer farming uses a special engine hook; Slavs modify both worker and farm.
4. Mixed-output bonuses need joint accounting: stone mining plus gold, wood plus
   gold, or farming plus gold cannot be priced as independent worker activities.
5. Passive income, trade, fish and pasture economies need explicit scenarios.
   Their output cannot be treated as free, unbounded villager income. Population
   use also matters, e.g. Mahayana and Feitoria.
6. Finite resources and gold access remain constraints, even when labor cost is
   low. Market prices and trade distances need scenario inputs.

## Proposed labor measures

For independent resource sources, let g_r be effective delivered resource r per
villager-second and C_r the unit's final resource cost:

    labor_per_replacement = sum_r(C_r / g_r)

If food is supplied by farms costing W_f wood and yielding Y food, add recurring
farm maintenance. Let g_F exclude reseeding and t_seed be worker-seconds spent
rebuilding one farm:

    L = F/g_F + (W + F*W_f/Y)/g_W + G/g_G + S/g_S + F*t_seed/Y

Do not add the reseeding term again if it is already included in an empirically
measured farming rate. Special farm yield/instant-income mechanics can change
this model. The CSV's wood-per-food ratio is a nominal seed-maintenance ratio.

    villagers_to_feed_one_building = L / training_seconds
    labor_to_replace_losses = sum_i(units_lost_i * L_i)

Faster training changes the continuous funding demand, not the labor cost of one
replacement. Compare the two metrics separately. Research costs are one-time
setup investment, not a charge every time a unit is replaced.

For mixed-output jobs j, use a resource-output vector y_jr and solve for worker
time x_j jointly: minimize sum_j x_j subject to sum_j y_jr*x_j >= required_r.
Resource availability, layout, income sources and passive-production limits must
be specified. Passive income credits depend on the rebuilding time horizon.

Army replacement labor requires actual killed-unit counts. Remaining HP alone
cannot distinguish surviving wounded units from units needing to be rebuilt.
Elapsed recovery also depends on building count, queues, starting stockpiles and
the allocation of villagers to resources; it is different from villager-seconds.

## Corrections and validation

The earlier generic resolver activated hidden 1-resource/1-second technologies
as if they were automatic. Their costs and times are deliberate activation
gates. The economy pass checks whether the civilization/team effects actually
make those technologies free and instantaneous, then rechecks prerequisites.
This prevents the Chinese farm team bonus leaking to other civilizations and
removes an unintended Shipwright effect from seven civilizations' naval entries.

Resource-change commands with a nonnegative c field scale the amount by the
referenced player resource. This is necessary for Chinese farm effects and
Sicilian farm-upgrade scaling; ignoring it produces incorrect farm capacities.

validation.json records coverage, source-command matches and numerical checks.
All work is in disposable review outputs; no serving database is changed.

Rebuild with tools/build_economy_review.py in the advisor worktree. The first raw
DAT extraction needs the genieutils virtualenv; subsequent runs use the cached
source snapshot. --extract refreshes it from the same recorded DAT.
