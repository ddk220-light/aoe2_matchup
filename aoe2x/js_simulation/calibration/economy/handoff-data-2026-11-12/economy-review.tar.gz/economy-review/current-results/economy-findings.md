# Source-derived economic findings

All values below use the supplied DAT and available post-Imperial upgrades. Work products exclude travel, drop-off and special income mechanics; they are not effective delivered income. Farm capacity retains source precision.

| Civilization | Nominal wood/min | Nominal gold/min | Farm food | Farm wood | Nominal farm wood/food |
|---|---:|---:|---:|---:|---:|
| Armenians | 38.339 | 33.381 | 375.00 | 60.00 | 0.1600 |
| Aztecs | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Bengalis | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Berbers | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Bohemians | 37.066 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Britons | 37.066 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Bulgarians | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Burgundians | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Burmese | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Byzantines | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Celts | 38.750 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Chinese | 37.066 | 30.153 | 412.50 | 60.00 | 0.1455 |
| Cumans | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Danes | 33.696 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Dravidians | 37.066 | 26.220 | 375.00 | 60.00 | 0.1600 |
| Ethiopians | 37.066 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Franks | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Georgians | 33.696 | 26.220 | 550.00 | 60.00 | 0.1091 |
| Goths | 37.066 | 26.220 | 550.00 | 60.00 | 0.1091 |
| Gurjaras | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Hindustanis | 37.066 | 33.168 | 375.00 | 60.00 | 0.1600 |
| Huns | 37.066 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Incas | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Italians | 37.066 | 26.220 | 550.00 | 60.00 | 0.1091 |
| Japanese | 37.066 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Jurchens | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Khitans | 37.066 | 26.220 | Unavailable | — | — |
| Khmer | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Koreans | 37.066 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Lithuanians | 37.066 | 26.220 | 550.00 | 60.00 | 0.1091 |
| Magyars | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Malay | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Malians | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Mapuche | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Mayans | 37.084 | 26.233 | 550.00 | 60.00 | 0.1091 |
| Mongols | 33.696 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Muisca | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Persians | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Poles | 33.696 | 26.220 | 550.00 | 60.00 | 0.1091 |
| Portuguese | 37.066 | 26.220 | 550.00 | 60.00 | 0.1091 |
| Romans | 35.381 | 31.661 | 550.00 | 60.00 | 0.1091 |
| Saracens | 37.066 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Saxons | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Shu | 37.066 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Sicilians | 33.696 | 30.153 | 1018.75 | 60.00 | 0.0589 |
| Slavs | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Spanish | 37.066 | 26.220 | 375.00 | 60.00 | 0.1600 |
| Tatars | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Teutons | 37.066 | 26.220 | 550.00 | 36.00 | 0.0655 |
| Tupi | 37.066 | 30.153 | 375.00 | 60.00 | 0.1600 |
| Turks | 37.066 | 37.691 | 375.00 | 60.00 | 0.1600 |
| Varangians | 37.066 | 26.220 | 550.00 | 60.00 | 0.1091 |
| Vietnamese | 37.066 | 26.220 | 550.00 | 60.00 | 0.1091 |
| Vikings | 37.066 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Wei | 33.696 | 30.153 | 550.00 | 60.00 | 0.1091 |
| Wu | 37.066 | 30.153 | 375.00 | 60.00 | 0.1600 |

## Standard upgrade effects

| Upgrade | Direct source effect | Modeling consequence |
|---|---|---|
| Double-Bit Axe / Bow Saw / Two-Man Saw | Lumberjack work rate ×1.20 / ×1.20 / ×1.10 | Apply available tiers and civ modifiers; then account for logistics. |
| Gold Mining / Gold Shaft Mining | Gold-miner work rate ×1.15 each | Missing the second tier matters in the final state. |
| Stone Mining / Stone Shaft Mining | Stone-miner work rate ×1.15 each | Keep secondary resource-generation effects separate. |
| Horse Collar / Heavy Plow / Crop Rotation | Farm food +75 / +125 / +175, scaled by the farm-upgrade resource multiplier | Lower recurring reseeding wood/labor; not a direct gather multiplier. |
| Heavy Plow | Farmer carry capacity +1 in addition to farm food | A logistics effect, alongside longer-lived farms. |
| Wheelbarrow | Villager speed ×1.10 and raw carry capacity ×1.2695 in this file | Need cargo rounding and walking; no universal income percentage. |
| Hand Cart | Villager speed ×1.10 and carry capacity ×1.50 | Same qualification; free research does not apply a second modifier. |
| Fishing Lines / Gillnets | Fishing-ship work rate ×1.10 and capacity +5 each | Use a fishing scenario, not villager mining/farming rates. |
| Caravan | Trade-unit movement and work rate ×1.20 | Distance and trade mechanics remain necessary. |
| Guilds | Market resource parameter set to 0.15 | Market transactions belong to a price-dependent scenario. |
| Domestication / Pastoralism / Transhumance | Pasture parameters changed separately from farm parameters | Khitan food needs a pasture model. |
| Mahayana | Villager population-storage amount set to -0.9 | Changes population capacity, not output per worker. |

## Continuous production examples

One Spanish production building, final training modifiers, excluding farm maintenance:

| Unit | Cost | Seconds/unit | Food/min | Wood/min | Gold/min |
|---|---|---:|---:|---:|---:|
| Halberdier | 35F + 25W | 16.54 | 126.95 | 90.68 | 0.00 |
| Hussar | 80F | 22.56 | 212.80 | 0.00 | 0.00 |
| Paladin | 60F + 75G | 22.56 | 159.60 | 0.00 | 199.50 |

The independent labor model and the handling of mixed outputs, passive income, farm upkeep and battle losses are described in README.md.

## Earlier-draft correction

35 naval training entries in seven civilizations had an unintended Shipwright variant applied. unit-funding-demand.csv uses the corrected timing; production-corrections.csv lists every affected entry. The source resolver has been corrected and a fresh production review is included separately.
