# Gold gathering simulation: first experiment

Status: first implementation completed. Results and playback are in
[/workspace/aoe2_matchup-advisor/aoe2x/js_simulation/calibration/economy/gold-2026-11-09/README.md](/workspace/aoe2_matchup-advisor/aoe2x/js_simulation/calibration/economy/gold-2026-11-09/README.md).
The implementation uses an 80 Hz default after timestep checks; the original
plan below records the initial design. Reference comparison is complete; matched
current-DE gathering captures have not been validated.

Goal: measure delivered gold per villager-second for ten generic, fully upgraded
post-Imperial villagers working four gold tiles in a 2×2 square, with one empty
tile between the gold and an already-built Mining Camp. Explain the difference
between nominal work and delivered resources through walking, congestion, task
transitions and carrying capacity.

## Fixed baseline and source inputs

Use a synthetic generic profile extracted from Byzantine gold miners. The
review database confirms their four relevant technologies are available and
their gold-mining work, movement and carry effects come only from these standard
technologies. Do not apply Byzantine building HP/age-cost bonuses or any team
bonuses to the synthetic scenario. Other standard eco technologies can be marked
researched but have no effect on gold harvesting. No research/construction time
is charged within the measurement window.

Source: `/workspace/scratch/economy-review/labor-inputs/labor-inputs.sqlite`,
derived from the user's DAT archive dated 2026-10-29, SHA-256
`d0aefd92428e2215d6f4d9b1d544901e6f171e19183f9e0b88218de5153a337f`.

| Parameter | Source-derived value | Interpretation |
|---|---|---|
| Gold miners | Unit IDs 579/581 | Male/female mining forms; check equivalent relevant stats |
| Base mining work | 0.38 gold/game-second | Work while harvesting, excludes movement |
| Gold Mining, Gold Shaft Mining | ×1.15 each | Final nominal rate ≈0.50255 gold/game-second |
| Base movement | 0.8 tiles/game-second | Apply Wheelbarrow and Hand Cart ×1.10 each |
| Final movement | ≈0.968 tiles/game-second | Do not convert using wall-clock speed |
| Base carry | 10 gold | Raw sequential multipliers: 1.2695 and 1.5 |
| Unrounded carry product | ≈19.0425 | Not an assertion of runtime load capacity |
| Proposed runtime carry | 20 gold, provisional | Community testing reports rounding after upgrades; verify against current DE |
| Villager collision size X/Y | 0.2/0.2 tiles | Initial circle approximation r=0.2; actual contact/overlap policy requires validation |
| Minimum collision-size multiplier | 0.25 | Preserve as a source field; do not apply universally without knowing activation conditions |
| Gold unit 66 collision size X/Y | 0.5/0.5 | A 1×1-tile static footprint |
| Gold supply | 800 per tile | Four independent finite stores, total 3,200 |
| Mining Camp 584 collision size X/Y | 1/1 | A 2×2-tile static footprint; age variants retained |
| Mining task | Action 5, target 66, resource 3, multiplier resource 47 | Work value 1; source work range 0; contact semantics need confirmation |
| Mining task search wait | 3 seconds | Raw task field; do not assume it is a per-load drop-off delay |

At uninterrupted nominal work, ten villagers extract at most approximately
301.53 gold in 60 game-seconds. This is an extraction bound, not a predicted
delivered result. For a warmed-up window, pre-existing carried gold can make
banked gold differ from gold extracted during that window.

## Geometry and initial conditions

Use map-tile coordinates, independent of isometric screen projection:

```
G G     gold footprint: x=[10,12], y=[10,12]
G G     each G is a separate 1×1 object
. .     empty row: y=[12,13]
C C     camp footprint: x=[10,12], y=[13,15]
C C
```

Gold centers: (10.5,10.5), (11.5,10.5), (10.5,11.5), (11.5,11.5).
Camp center: (11,14). "One tile away" means a one-tile edge-to-edge gap.
Keep surrounding terrain flat, open and otherwise empty.

Proposed reproducible starting villager centers, already around the gold:
south [(10.3,12.2),(10.9,12.2),(11.5,12.2)],
east [(12.2,10.3),(12.2,10.9),(12.2,11.5)],
north [(10.3,9.8),(11.2,9.8)], west [(9.8,10.3),(9.8,11.2)].
Check positions against the chosen collision representation before execution.
All inventories and the gold bank start at zero. Assign each worker its nearest
gold object at time zero with deterministic tie-breaking; export the exact
assignments so the same scenario can be recreated in DE. Initial placement is
scenario input, not a prescribed route or a congestion correction.

## Implementation sequence

1. Export a small JSON fixture with the values, geometry, upgrades, provenance,
   starting positions and unresolved mechanics above. Validate the raw-to-final
   effect chain and keep rounding as an explicit policy.
2. Implement one worker's cycle: reach a legal mining contact point → gather
   into personal inventory → seek a legal camp-edge drop-off point when full →
   deposit → return to a reachable point on the assigned gold object. Retarget
   only when justified by depletion or blocked-target rules. Expose unresolved
   contact, task-switch and deposit behavior rather than inventing delays.
3. Add ten-agent movement and congestion: static obstacle routing around the
   square gold/camp footprints; finite-size villagers; local avoidance,
   opposing traffic, blocked-worker waiting and replanning. Deposits are not a
   single-server queue unless the game exhibits that behavior. Do not assign an
   invented fixed number of miners per gold tile.
4. Use fixed-step updates, initially 0.05 game-seconds, with events resolved at
   exact boundary times where practical. Compare 0.1/0.05/0.025-second steps;
   investigate material changes. Gather only for the portion of each step spent
   working; walking/blocked workers must not continue harvesting.
5. Record per-worker positions, state, inventory, resource target, path length,
   deposits, gathered amount and time spent working/walking/blocked/switching.
   Include a simple top-down playback so routing and queues can be inspected.

Existing movement/collision code is a starting point for reusable geometry and
movement primitives, not an already-validated villager simulator. Inspection
found circular static-obstacle handling and combat-specific interaction/formation
policies. The mining case needs rectangular footprints and worker behavior.
Keep the experiment separate from battle simulation; do not apply combat
formation compression or attack-contact rules to workers automatically.

## Measurements and trial matrix

Run the requested 0–60-second baseline first. Report:

- gold deposited by exactly 60 seconds;
- gold still carried at 60 seconds;
- gold removed from each resource object;
- per-villager banked gold/minute and extraction rate;
- working, walking, blocked and task-switch time shares;
- path distance, deposit counts and maximum unresolved overlap.

For any interval [a,b], verify:

`extracted = banked_delta + carried_at_b - carried_at_a`.

Do not force an extra drop-off after the deadline and count it inside the timed
minute. Resource totals retain precision even if the UI displays rounded values.

Also run a 120-second warm-up followed by the same 60-second measurement and a
longer 300-second measurement to expose short-window/load-cycle bias. Report
carried-inventory changes in each window. Record depletion; do not silently
reset deposits mid-run or combine depleted and non-depleted periods.

Keep the first diagnostic sweep small:

| Trial | Purpose |
|---|---|
| Stationary, uninterrupted work | Verify the exact source work rate and resource conservation |
| One worker with hauling | Isolate carry rounding, contact distance and drop-off cycle |
| Ten independent workers with worker collisions disabled | Diagnostic walking-only control, not a real-game estimate |
| Ten workers with interactions enabled | Requested scenario; quantify congestion loss against the control |
| Five and fifteen workers, same geometry | Check that behavior generalizes to different crowding |
| Camp gaps 0 and 2, otherwise unchanged | Check distance/geometry behavior without fitting the one-tile case |

The exact baseline should be reproducible. Then use ten explicitly recorded,
legal initial-position/order variations to measure scenario sensitivity. These
are not claimed to reproduce DE's RNG distribution. Compare matched scenarios
across implementations and retain every result; report median and range.

## External comparison and validation

Online references were checked on 2026-11-09. The source DAT remains the authority
for numeric unit/technology inputs. Online rates are comparison evidence, not
runtime constants.

| Reference | Useful evidence | Limits |
|---|---|---|
| [Forgotten Empires: Gold & Relics](https://www.forgottenempires.net/strategy/age-of-empires-ii-strategy-center/gold-relics) | Its one-tile, no-bumping table gives 20.5 seconds per 10 gold with Gold Shaft Mining and Hand Cart: ≈29.27 gold/villager-minute | Patch unspecified; excludes crowding; not an exact prediction for our ten-agent layout |
| [Four-tile mining-camp experiment](https://www.reddit.com/r/aoe2/comments/1ibcnqu/where_to_place_your_mining_camp_and_how_many/) | Ten villagers, four gold tiles, one-tile camp gap; useful qualitative layout evidence | Explicitly no mining/carry upgrades, no duration stated, exact gold shape unspecified; 890 total cannot be converted to a rate |
| [Gold-mining saturation experiment](https://www.reddit.com/r/aoe2/comments/xsm93t/experiment_villagers_and_gold_mining_saturation/) | Documents diminishing per-worker output and a second-camp test; ten-worker result 99.9 gold/worker over its nominal four-minute window | Seven tiles, Castle Age, Wheelbarrow + Gold Mining only; end forced drop-off without corresponding initial carry accounting biases the window |
| [DE Infosheet](https://steamcommunity.com/sharedfiles/filedetails/?id=2169547705) | Reports effective carry 13 then 20 and the same raw 1.2695/1.5 modifiers found in our DAT | Updated November 2021; rounding explanation is presented as a hypothesis, so current-engine verification remains necessary |

For the first comparison, show our one-worker settled throughput beside the
Forgotten Empires rate and our ten-worker result beside its own collision-off
control. Do not apply an arbitrary 'bumping percentage' to reach 29.27.

To establish DE fidelity, the decisive check is an equivalent current-game
scenario using the same patch, upgrades, positions, assignments, map geometry and
game-clock windows. Measure current carry capacity, first-load timing, contact
behavior, passability around working villagers, subsequent deposit cycles and
the aggregate time series. Existing capture infrastructure may help, but verify
that it actually records inventory/bank/resource state as well as positions.
If no matched capture is available, label the output 'unvalidated model estimate'.

Proposed acceptance criteria:

- exact resource accounting and repeatability;
- no unexplained penetration of static obstacles or movement beyond the permitted
  speed under the chosen collision policy;
- numerical convergence below 1% in a longer aggregate throughput comparison;
- aim for within 5% of matched DE steady-throughput measurements across the
  baseline and held-out worker-count/distance cases, accounting for observed
  scenario variation and inventory endpoints;
- inspect individual deposit-cycle timing too: a matching total can conceal
  incorrect walking, carry or collision mechanics.

These are proposed validation targets, not claims that a simulation or validation
has already succeeded. Fix general mechanics where evidence identifies a mismatch;
do not tune scenario-specific radii, pauses, paths or harvest rates to force agreement.

## First deliverable and later use

Deliver one frozen fixture, a source-parameter manifest, the worker simulation,
inspectable playback/event log, and a table containing first-minute gold,
settled gold/villager-minute, carried inventory and congestion/time breakdown.
Show external-reference comparability and remaining unknowns next to the results.

Only after this generic baseline behaves credibly should civilization modifiers
be introduced. The eventual gold-only replacement labor is unit gold cost divided
by validated delivered gold per villager-second for a stated scenario. It is
separate from the later question of how many workers sustain a production building.
