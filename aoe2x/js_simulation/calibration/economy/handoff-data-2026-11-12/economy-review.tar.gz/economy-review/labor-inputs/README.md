# Economic inputs for labor per replacement

Source: user-supplied DAT, archive dated 2026-10-29, SHA-256 `d0aefd92428e2215d6f4d9b1d544901e6f171e19183f9e0b88218de5153a337f`. No external game descriptions used.

This inventory records parameters, upgrade availability and source evidence for all 56 civilizations. Effective resource income and villager-seconds per replacement are deliberately uncalculated.

The table lists active economic effect labels and special infrastructure; some labels are internal names. Detailed notes, exact commands, activation prerequisites and unresolved mechanics are in the CSVs and database. A blank direct-bonus list does not imply identical economies: missing upgrades still matter.

| Civilization | Economic effects/infrastructure detected | Missing standard land upgrades | Free economic research (setup only) |
|---|---|---|---|
| Armenians | Cheaper Mule Cart; +% Wood up; +% Gold up; +% Stone up; Fortified Church; Mule Cart; Conditional: Free Relic; Conditional: Free Relic2 | Two-Man Saw; Stone Shaft Mining; Crop Rotation | None |
| Aztecs | Aztecs Tech Tree; Aztecs Team Bonus; +50g | Two-Man Saw | None |
| Bengalis | Bengalis Team Bonus; Free Villagers; Mahayana | Stone Shaft Mining | None |
| Berbers | Villagers 5% faster; Ships +10% faster; Villagers 10% faster | Two-Man Saw | None |
| Bohemians | Bohemians Team Bonus; Villager Fervor | Crop Rotation | Gold Mining; Gold Shaft Mining; Stone Mining; Stone Shaft Mining |
| Britons | +25% Shepherd; 1/2 TCs | Stone Shaft Mining; Crop Rotation | None |
| Bulgarians | TC Cost 1/2 Stone | Two-Man Saw | None |
| Burgundians | Burgundians Team Bonus; Burgundian Vineyards; Flemish Revolution | None | None |
| Burmese | No direct effect identified | Stone Shaft Mining | Double-Bit Axe; Bow Saw; Two-Man Saw |
| Byzantines | No direct effect identified | None | None |
| Celts | Lumberjacks 15% faster | Two-Man Saw; Crop Rotation | None |
| Chinese | Chinese TB (Reapply); Techs -15% cost; -200f -50w; Tec Cost; Start w/ 6 villagers | Crop Rotation | None |
| Cumans | Change TC constr time1; Change TC constr time2 | Stone Shaft Mining | None |
| Danes | Razing Bounty | Two-Man Saw; Crop Rotation | None |
| Dravidians | Fish carry; +200w; Conditional: +200w | Gold Shaft Mining; Stone Shaft Mining; Crop Rotation | None |
| Ethiopians | +100f, +100g in age2; +100f, +100g in age3; +100f, +100g in age4; Conditional: +100f, +100g in age2 | Crop Rotation | None |
| Franks | 15% faster foragers | Two-Man Saw; Stone Shaft Mining | Horse Collar; Heavy Plow; Crop Rotation |
| Georgians | Georgians Team Bonus; Fortified Church area effect; Start w/ mule cart; Fortified Church; Mule Cart | Two-Man Saw; Gold Shaft Mining | None |
| Goths | Hunting bonuses; +10 pop | Gold Shaft Mining | None |
| Gurjaras | Herdables garrison; Start w/ 2 bushes | Two-Man Saw | None |
| Hindustanis | Villager cost Age1; Villager cost Age2; Villager cost Age3; Grand Trunk Road; Villager cost Age4; Caravanserai | Crop Rotation | None |
| Huns | Huns Tech Tree; Start w/ Horse; Disable Horse | Stone Shaft Mining; Crop Rotation | None |
| Incas | Building Stone cost; TC Stone cost; Settlement | Two-Man Saw | None |
| Italians | Italians Tech Tree; Silk Road | Gold Shaft Mining | None |
| Japanese | Better Fishing Ships; Gather Price; C-Bonus | Stone Shaft Mining; Crop Rotation | None |
| Jurchens | Animals don't decay | None | None |
| Khitans | Pasture upgrade 1; Pasture upgrade 2; Pasture upgrade 3; Pasture | Gold Shaft Mining; Horse Collar; Heavy Plow; Crop Rotation | None |
| Khmer | Instant Farmers; Houses garrison | Two-Man Saw | None |
| Koreans | Koreans Tech Tree | Crop Rotation | None |
| Lithuanians | +100 food per TC | Gold Shaft Mining | None |
| Magyars | No direct effect identified | Stone Shaft Mining | None |
| Malay | Fish Trap 33% cheaper; 3x food fish traps | Two-Man Saw | None |
| Malians | Gold productivity; buildings cost -15% w; TC Wood cost | Two-Man Saw | None |
| Mapuche | Cavalry gold; Forager productivity; Settlement | Two-Man Saw | None |
| Mayans | Mayans Tech Tree; -50f; Start w/ 4 villagers | Gold Shaft Mining | None |
| Mongols | Hunters 40% faster | Two-Man Saw; Crop Rotation | None |
| Muisca | Muisca Team Bonus; Cheaper + Healing Settlement; Settlement | None | Caravan; Guilds |
| Persians | TC and Dock work rate; +50f +50w; Caravanserai | None | None |
| Poles | Enable Folwark; Stone Miners generate gold; Folwark | Two-Man Saw; Gold Shaft Mining | None |
| Portuguese | Portuguese Team Bonus; Foragers generate wood; All units -20% gold; Circumnavigation; Feitoria | Gold Shaft Mining | None |
| Romans | Villagers work faster | Two-Man Saw; Stone Shaft Mining | None |
| Saracens | Market | Stone Shaft Mining; Crop Rotation | None |
| Saxons | Saxons Team Bonus; Dropsites +35 food, +10 stone | Stone Shaft Mining | None |
| Shu | Lumberjacks food | Stone Shaft Mining; Crop Rotation | None |
| Sicilians | Farms extra food; First Crusade; +100s; Fast Castle and TC | Two-Man Saw | None |
| Slavs | Slavs Tech Tree | Stone Shaft Mining | None |
| Spanish | Spanish Tech Tree; Spanish Team Bonus; Tech reward; Exclude from tech reward; TC constr time | Gold Shaft Mining; Crop Rotation | None |
| Tatars | Sheep +50% food | Two-Man Saw; Stone Shaft Mining | None |
| Teutons | Cheap Farms | Gold Shaft Mining | None |
| Tupi | Unit Refund; +25 each res; Settlement; Conditional: Post-TC +25 each res | Stone Shaft Mining; Crop Rotation | None |
| Turks | Mining +25% | Stone Shaft Mining; Crop Rotation | None |
| Varangians | gold from sheep, hunt, fishing ships; VG +33% more gold; C-Bonus Caravan 50% more effective | Gold Shaft Mining | None |
| Vietnamese | Paper Money; Paper Money + Double-Bit Axe; Paper Money + Bow Saw; Paper Money + Two-Man Saw | Gold Shaft Mining | None |
| Vikings | Vikings Team Bonus | Stone Shaft Mining | Wheelbarrow; Hand Cart |
| Wei | Tuntian | Two-Man Saw | None |
| Wu | Military Buildings +55f | Crop Rotation | None |

## Mechanics requiring separate treatment

| Civilization | Mechanic | Source effect |
|---|---|---|
| Aztecs | Villager carrying capacity +3 before subsequent carry modifiers. | 447 |
| Aztecs | Relic-gold parameter ×1.33; requires relic count and elapsed time. | 488 |
| Bengalis | Trade-food parameter 251 increases by 10; trade route and payout semantics remain to model. | 841 |
| Bengalis | Mahayana sets villager population use to 0.9; this is not faster harvesting. | 853 |
| Berbers | Villager movement ×1.05; later effect 626 multiplies by 1.047619 (about ×1.10 together). | 609 |
| Berbers | Fishing/trade ship movement ×1.10; trade-cog work also ×1.10. | 611 |
| Berbers | Second villager movement modifier ×1.047619. | 626 |
| Bohemians | Fervor-linked hidden technology gives villagers movement ×1.15. | 826 |
| Britons | Shepherd work rate ×1.25. | 381 |
| Britons | Town Center wood cost ×0.50. | 379 |
| Bulgarians | Town Center stone cost ×0.50. | 731 |
| Burgundians | Relic-food parameter 225 increases by 20; relic holdings must be specified. | 783 |
| Burgundians | Burgundian Vineyards: resource 236 +2, engine hook 14; retain as farming-linked gold mechanic, not an assumed income rate. | 790 |
| Burgundians | Flemish Revolution triggers engine hook 55; workforce conversion is an event, not a gather bonus. | 791 |
| Celts | Lumberjack work ×1.15; missing Two-Man Saw is recorded separately. | 384 |
| Chinese | Chinese own-team effect multiplies farm/pasture food and the farm-upgrade multiplier by 1.10. | 240 |
| Danes | Razing-bounty parameter 291 +250 and hook 36 with multiple player scopes; event income, not passive worker output. | 1485 |
| Dravidians | Fishing ships and shore-fishing worker variants gain +15 carry; exact target IDs retained. | 863 |
| Dravidians | Age-triggered +200 wood per activation; not recurring villager income. | 868 |
| Dravidians | Age-triggered +200 wood per activation; not recurring villager income. | 868 |
| Dravidians | Age-triggered +200 wood per activation; not recurring villager income. | 868 |
| Ethiopians | Feudal-age trigger adds 100 food and 100 gold. | 613 |
| Ethiopians | Castle-age trigger adds 100 food and 100 gold. | 614 |
| Ethiopians | Imperial-age trigger adds 100 food and 100 gold. | 615 |
| Franks | Forager work rate ×1.15. | 523 |
| Georgians | Team effect multiplies resource 271 by 0.75; retain parameter, confirm its repair-cost accounting in the engine. | 928 |
| Georgians | Fortified Church area effect invokes engine hook 9. Radius, worker coverage and stacking are not encoded by this command. | 939 |
| Goths | Hunters gain +15 carry; hunt multiplier ×1.23 paired with worker work ×0.813008. Yield and work must be modeled together. | 414 |
| Gurjaras | Mill garrison type/capacity are changed (capacity 10); herdable-income parameter 254 is set to 15. Herdable composition matters. | 871 |
| Hindustanis | Grand Trunk Road changes gold miners, trade units, relic/passive-gold parameters and market parameters; all targets retained separately. | 562 |
| Italians | Silk Road multiplies specified trade-unit resource costs by 0.50. | 554 |
| Japanese | Fishing-ship work ×1.05, followed by further age-specific modifiers; survival bonuses kept separately. | 306 |
| Japanese | Mill, Lumber Camp and Mining Camp costs ×0.50. | 338 |
| Jurchens | Animal-decay switch resource 292 is set to 1; compare available food, not a flat harvest-rate increase. | 993 |
| Khitans | First pasture upgrade adds 115 × resource 69 to resource 288 and +1 to resource 289. | 1014 |
| Khitans | Second pasture upgrade adds 230 × resource 69 to resource 288 and +2 to resource 289. | 1013 |
| Khitans | Third pasture upgrade adds 345 × resource 69 to resource 288 and +3 to resource 289. | 1012 |
| Khmer | Khmer Instant Farmers hook 50 plus farmer work ×0.95; cannot evaluate as a simple 5% income reduction. | 690 |
| Khmer | House variants gain garrison capacity 5 and garrison type 1; protection, not a faster gather rate. | 693 |
| Koreans | Stone-miner work ×1.20; other tree commands are retained as raw provenance. | 504 |
| Lithuanians | Town Center annex 890 has its dead-unit target set to hidden food object 888; completion/death chain grants the source-labelled 100 food per Town Center. | 734 |
| Malay | Fish Trap resource cost ×0.66667. | 675 |
| Malay | Fish-trap food parameter 88 is set to 2130; retain exact value rather than relying on the effect label. | 677 |
| Malians | Gold-productivity parameter 276 +10; engine accounting needs confirmation. | 621 |
| Malians | Building wood-cost modifiers, including exclusions/reapplications, are retained; do not apply a blanket discount to farms. | 617 |
| Mapuche | Cavalry-gold source label invokes hook 26; eligible kills/units and amount need engine validation. | 62 |
| Mapuche | Forager-productivity parameter 215 +25 and engine hook 29; exact credited/depleted-resource rule remains unresolved. | 1381 |
| Mayans | Multiple task-output multipliers ×1.15 paired with lower worker work rates (farmer ×0.81, many other jobs ×0.87). | 449 |
| Mongols | Hunter work rate ×1.40. | 388 |
| Muisca | Gold task multiplier ×1.15 paired with miner work ×0.869565; resource yield is distinct from collection speed. | 1357 |
| Muisca | Settlement cost ×0.67 and healing-related hook 28; raw settlement forms retained. | 1368 |
| Persians | Town Center/Dock work modifiers differ by age-specific unit ID: ×1.05/1.10/1.15/1.20. This affects queues, not villager harvest work. | 421 |
| Poles | Folwark replaces Mill variants; resource 237 = 0.10 × farm-food parameter 36, plus parameters 238/239. Farm placement/renewal rules remain to model. | 816 |
| Poles | Stone-mining gold mechanic: resource 241 +33.3333015 and hook 13. Keep gold and stone as joint outputs. | 827 |
| Portuguese | Forager-generated wood: resource 267 +33.3333015. Keep food and wood as joint outputs. | 510 |
| Romans | Villagers work ×1.05; farmers additionally ×1.038095 and Farm work ×1.05. These are separate parameters, not a measured income uplift. | 898 |
| Saracens | Market cost reduced by 100 wood and market fee parameter changed; trades need a price/quantity scenario. | 354 |
| Saxons | Repairer work rate ×1.25. | 1455 |
| Saxons | Drop-site variants receive resource-storage changes labelled +35 food/+10 stone; completion event semantics retained for review. | 1465 |
| Shu | Lumberjack-food parameter 502 +7 and engine hook 16; preserve wood and food together. | 1071 |
| Sicilians | Farm-upgrade food multiplier ×2.25; does not multiply the initial farm food by 2.25. | 797 |
| Slavs | Farmer work ×1.23 and Farm work ×1.15; both enter the future farming model. | 7 |
| Spanish | Builder work ×1.30; research pricing and other tree commands remain separately recorded. | 446 |
| Spanish | Specified trade-unit work rate ×1.25; payout/distance logic still required. | 490 |
| Spanish | Research reward parameter 269 points to effect 300, which grants gold. This is setup income, not per-replacement harvesting. | 181 |
| Tatars | Herdable-food multiplier ×1.57 paired with shepherd/herder work ×0.637; exact stored factors retained. | 741 |
| Teutons | Farm cost ×0.60: 36 wood for a standard 60-wood farm in this supplied DAT. | 314 |
| Tupi | Unit Refund hook 27 and parameter 295 = 0.15. Eligible units, trigger and refund resource basis need engine validation. | 1396 |
| Turks | Gold-miner work rate ×1.25. | 295 |
| Varangians | Source-labelled gold from sheep/hunt/fishing ships: hook 34 and parameter 298 = 10.0100002. | 1475 |
| Varangians | Caravan-linked extra trade movement and work ×1.0835; do not turn both modifiers into a guessed income percentage. | 1490 |
| Vietnamese | Paper Money: gold parameter 266 +1.5 and hook 15; additional hidden modifiers follow researched wood upgrades. | 669 |
| Vietnamese | Paper Money parameter ×1.20 conditional on Double-Bit Axe. | 881 |
| Vietnamese | Paper Money parameter ×1.20 conditional on Bow Saw. | 882 |
| Vietnamese | Paper Money parameter ×1.10 conditional on Two-Man Saw. | 883 |
| Vikings | Dock costs ×0.85. | 411 |
| Wei | Tuntian: parameter 287 +3 and hook 4; income source/counting semantics remain unresolved. | 1061 |
| Wu | Military-building food reward is stored through resource-storage attribute 27, including Docks. | 1084 |

## Files

- `labor-inputs.sqlite`: full relational inventory, raw definitions, active commands and provenance.
- `civilization-summary.csv`: all 56 civilizations, upgrade gaps, free/discounted research and unresolved labels.
- `civilization-mechanics.csv`: classified economic effects and special infrastructure with exact evidence.
- `standard-upgrade-availability.csv`: available/missing/free/instant, costs, rewards, research time and modifiers.
- `actor-parameters.csv`: base/final work, movement, carry, population, costs, drop sites and evidence.
- `replacement-resource-costs.csv`: 1,030 advisor entries; labor remains null pending calibrated rates.
- `unresolved-effect-candidates.csv`: raw hooks/resources whose economic scope is not established; includes military effects.
- `conditional-economic-effects.csv`: dormant economic candidates and exact prerequisites/events, including unavailable-upgrade branches; these are not applied to final work parameters.
- `manifest.json`, `validation.json`: assumptions, limitations, source identity and verification.

Raw definitions preserve tasks, farm buffers, resource storage/decay, drop sites, garrisons, construction/training definitions and age/annex forms. Resource-object candidates include scenario/editor records and must be filtered for a later simulation.

Future labor model: replacement resource vector plus recurring inputs (such as reseeding wood/time), divided by calibrated delivered-output rates. Mixed-output jobs require joint allocation; refunds and passive income require explicit conditions. Research setup costs are excluded from each replacement.
