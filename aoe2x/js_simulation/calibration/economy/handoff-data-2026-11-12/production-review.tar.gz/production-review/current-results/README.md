# Production review — supplied November 9 game-data archive

The first pass covers all **1,030 advisor unit/civilization rows across 56 civilizations**.
Every row has a calculated production time. Eight substantive cases remain marked
for owner review; numerical output for those cases is provisional.

## Source

`aoe2_dat.zip`, supplied through Google Drive:
https://drive.google.com/file/d/1OQSKmNacywATiLjMBxUoVHRvtwdz7X9o/view

The calculation uses its `dat/empires2_x2_p1.dat` and matching `dat/CivTechTrees`.
The DAT is format `VER 8.9`, has an archive timestamp of October 29, 2026, and SHA-256
`d0aefd92428e2215d6f4d9b1d544901e6f171e19183f9e0b88218de5153a337f`.
Its Elephant Archer HP/food cost and Bolas Rider movement speed match the known
patch 188329 changes. The exact executable build number is not embedded in the DAT.

All production values and modifier commands come from these supplied files.
The existing advisor database supplies only the comparison roster, labels, and
comparison base times. No older DAT values or manually curated bonus percentages
are substituted into these calculations.

## Files to review

- `unit-production.csv`: one row per advisor unit/civilization; selected building,
  base and final production time, units per game minute, wood/stone/food/gold
  building costs, weighted cost, modifiers, and review flags.
- `civilization-summary.md`: production and building-cost differences for each of
  the 56 civilizations, alternate building choices, and review boundaries.
- `production-review.sqlite`: the temporary database, including all alternatives,
  per-command provenance, raw effect/technology definitions, and technology states.
- `all-production-buildings.csv`: every candidate production route retained by
  the first pass, with the selected route marked.
- `review-exceptions.csv`: all annotations, including routine transformed-unit links.
- `substantive-review-cases.csv`: the eight cases worth reviewing first.
- `all-source-units.csv`: 1,486 grouped source candidates, including economic units
  and units outside the advisor roster, with the cheapest building selected.
- `source-trainable-units.csv`: the broader source inventory before route selection;
  availability remains a first-pass interpretation of the game files.
- `manifest.json` and `validation.json`: exact provenance, assumptions, coverage,
  and checks performed.

## Calculation rules

- Fully upgraded Imperial Age, with the civilization's own team bonus and all
  available applicable technologies researched. Other allies are not included.
- `seconds = modified unit training time / modified production-building work rate`.
- Select the lowest `wood + 2 * stone` building cost. Ties select the faster route.
  Actual wood and stone amounts remain separate. Construction labor, prerequisite
  buildings and unlock research costs are not part of this building-cost figure.
- Current multi-location records and technology unlocks are followed, including
  attribute 158 selecting a location slot and attribute 42 changing its building.
- Every applied modifier records its effect/technology, command index, target,
  raw operation/value and before/after values. All alternative routes are retained.
- One-time transformations and unusual availability are flagged for review rather
  than silently interpreted as unlimited repeatable production.

## Examples

| Civilization / unit | Selected building | Seconds per unit | Building cost |
|---|---|---:|---|
| Huns Paladin | Stable | 18.80 | 175 wood |
| Huns Elite Tarkan | Stable | 15.04 | 175 wood |
| Aztecs Champion | Barracks | 13.73 | 175 wood |
| Goths Elite Huskarl | Barracks | 5.01 | 175 wood |
| Sicilians Elite Serjeant | Donjon | 9.02 | 50 wood + 175 stone |
| Burgundians Flemish Militia | Barracks | 10.53 | 175 wood |

The Tarkan's Castle route is faster (10.53 seconds), but its Stable route is much
cheaper to establish, so the user's cost-selection rule chooses the Stable.
Flemish Militia's repeatable-training result is provisional alongside the separate
Flemish Revolution transformation effects.

The eight substantive cases are Elite Ratha (Melee), Xebec, Flemish Militia,
Chinese Fire Ship, Elite Huskarl, Elite Tarkan, Elite Temple Guard and Wei
Two-Handed Swordsman. Huskarl and Tarkan base-time differences are explained by
selecting a different building from the existing reference database. The remaining
annotations and raw records are available for review before changing any rules.

The main databases and combat simulations have not been changed.

## Rerun

```bash
python tools/build_production_review.py \
  --raw-json /workspace/scratch/production-review/current-raw-source.json \
  --game-trees /workspace/scratch/production-review/current-input/dat/CivTechTrees \
  --out /workspace/scratch/production-review/current-results
```

For a fresh binary extraction, replace `--raw-json` with `--dat` and run the
script using the venv with `genieutils-py` installed. The source archive and raw
extraction are retained locally for subsequent iterations.
