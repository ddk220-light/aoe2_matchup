# Historical prototype — not a current-patch review dataset

The user requires the latest game data. These prototype results were generated
from the AoE2-Civbuilder DAT snapshot committed on 2025-08-10, SHA-256
`982e7c40eb547da4c0d66525d92ccc9f1b9022a0410890095780f25963e322ec`.
They must not be treated as current-patch production timings or imported into the
main database. They are retained only to exercise the first-pass extraction logic.

The latest checked AoE2 Tech Tree data update is patch 188329, committed on
2026-10-27 at `e56728e76b7d08301fba7b18d5f16bc8554c109a`. Its public stat export
does not contain the raw effect commands required by this derivation.

Current-patch input still needed:

- `resources/_common/dat/empires2_x2_p1.dat`
- Matching `resources/_common/dat/CivTechTrees/*.json` for current availability
  and regional grants.

The historical source covers 50 of the current advisor's 56 civilizations.
102 advisor rows belong to the six missing civilizations, and another 70 use unit
IDs absent from the source. The prototype records gaps rather than filling them
with guessed values. Source-only availability candidates are also provisional.

Generator: `/workspace/aoe2_matchup-advisor/tools/build_production_review.py`.
The main databases and simulation data have not been modified.
