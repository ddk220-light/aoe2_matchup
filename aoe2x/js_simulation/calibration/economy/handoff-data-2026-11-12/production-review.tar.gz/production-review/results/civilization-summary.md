# Civilization production review — first pass

Historical DAT snapshot (2025); fully researched Imperial. All numbers and modifier rules come from that source. Current roster supplies labels and comparison coverage only.

Building ranking: wood + 2 × stone. All alternatives remain in the database. Rows with review flags are provisional.

The broader source inventory is a candidate list: availability gates may over-include conditional or ally-granted units. Source-only candidates are marked below for owner review.

## Armenians

18 advisor roster units; 17 times calculated; 7 rows flagged. Separately, 21 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Capped Ram, Condottiero, Elite Genitour, Elite War Chariot, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_availability_needs_review`: Dromon, Fire Ship, Galleon, Heavy Demo Ship, Siege Ram.
- `unit_missing_from_source`: Carrack.
- `unit_not_resolved_as_trainable_in_final_source_state`: Dromon, Fire Ship, Galleon, Heavy Demo Ship, Siege Ram.

## Aztecs

15 advisor roster units; 13 times calculated; 5 rows flagged. Separately, 22 unit groups resolved from the source, including economic units.

- **Aztecs Tech Tree** (effect 447): unit training time multiply 0.869565; buildings: Archery Range, Barracks, Castle, Dock, Siege Workshop; units/candidates: Arbalester, Champion, Condottiero, Demo Ship, Demolition Ship, Elite Eagle Warrior, Elite Genitour, Elite Jaguar Warrior, Elite Skirmisher, Fast Fire Ship, Petard, Pikeman, Scorpion, Siege Onager, Siege Ram, Siege Tower, Trebuchet, War Galley.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, War Galley.
- `unit_missing_from_source`: Carrack, Catapult Galleon.

## Bengalis

18 advisor roster units; 17 times calculated; 5 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_availability_needs_review`: Elite Ratha (Melee).
- `unit_missing_from_source`: Carrack.
- `unit_not_resolved_as_trainable_in_final_source_state`: Elite Ratha (Melee).

## Berbers

22 advisor roster units; 21 times calculated; 5 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

- **Kasbah** (effect 607): production building work rate multiply 1.25; buildings: Castle; units/candidates: Elite Camel Archer, Petard, Trebuchet.

Source-only candidates (availability needs review): Condottiero, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_availability_needs_review`: Xebec.
- `unit_missing_from_source`: Carrack.
- `unit_not_resolved_as_trainable_in_final_source_state`: Xebec.

## Bohemians

19 advisor roster units; 17 times calculated; 5 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

- **Bohemians Team Bonus** (effect 804): production building work rate multiply 1.8; buildings: Market; units/candidates: Trade Cart.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Mounted Crossbowman.

## Britons

17 advisor roster units; 15 times calculated; 5 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **Britons Team Bonus** (effect 399): production building work rate multiply 1.1; buildings: Archery Range; units/candidates: Arbalester, Elite Genitour, Elite Skirmisher, Heavy Cavalry Archer.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Heavy Cavalry Archer, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Heavy Mounted Crossbowman, War Hulk.

## Bulgarians

17 advisor roster units; 16 times calculated; 5 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Elite Konnik, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Cheapest alternate-building selections:

- Elite Konnik: Krepost, 700.00 wood-equivalent, 12.03s.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Elite Konnik, Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Burgundians

20 advisor roster units; 18 times calculated; 6 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Cavalry Archer, Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Flemish Militia, Galleon.
- `special_production_or_transformation_effect_review`: Flemish Militia.
- `unit_missing_from_source`: Carrack, Mounted Crossbowman.

## Burmese

19 advisor roster units; 18 times calculated; 4 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Byzantines

21 advisor roster units; 19 times calculated; 5 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Elite Varangian Guard.

## Celts

17 advisor roster units; 15 times calculated; 5 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **Celts Team Bonus** (effect 401): production building work rate multiply 1.2; buildings: Siege Workshop; units/candidates: Heavy Scorpion, Siege Onager, Siege Ram, Siege Tower.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Heavy Cavalry Archer, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Heavy Mounted Crossbowman.

## Chinese

18 advisor roster units; 17 times calculated; 5 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Dragon Ship, Elite Genitour, Fishing Ship, Heavy Cavalry Archer, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_availability_needs_review`: Cavalry Archer, Fire Ship.
- `unit_missing_from_source`: Carrack.
- `unit_not_resolved_as_trainable_in_final_source_state`: Cavalry Archer, Fire Ship.

## Cumans

19 advisor roster units; 17 times calculated; 5 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

- **C-Bonus, Cheap Ranges and Stables** (effect 697): building cost add -75; buildings: Archery Range, Stable; units/candidates: Camel Rider, Crossbowman, Elite Genitour, Elite Skirmisher, Elite Steppe Lancer, Heavy Cavalry Archer, Hussar, Paladin.
- **Steppe Husbandry** (effect 726): unit training time multiply 0.5; buildings: Archery Range, Stable; units/candidates: Elite Steppe Lancer, Heavy Cavalry Archer, Hussar.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Catapult Galleon.

## Danes

18 advisor roster units; 0 times calculated; 18 rows flagged. Separately, 0 unit groups resolved from the source, including economic units.

Civilization absent from this DAT snapshot.

## Dravidians

20 advisor roster units; 19 times calculated; 4 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Ethiopians

19 advisor roster units; 18 times calculated; 4 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Franks

19 advisor roster units; 17 times calculated; 6 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

- **C-Bonus, Castle 15% cheaper** (effect 324): building cost multiply 0.85; buildings: Castle; units/candidates: Elite Throwing Axeman, Petard, Trebuchet.
- **C-Bonus, Castle 25% cheaper** (effect 329): building cost multiply 0.882353; buildings: Castle; units/candidates: Elite Throwing Axeman, Petard, Trebuchet.
- **Chivalry** (effect 548): production building work rate multiply 1.4; buildings: Stable; units/candidates: Light Cavalry, Paladin.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Heavy Cavalry Archer, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Elite Throwing Axeman, Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Heavy Mounted Crossbowman.

## Georgians

18 advisor roster units; 17 times calculated; 6 rows flagged. Separately, 21 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Elite War Chariot, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_availability_needs_review`: Cannon Galleon, Demo Ship, Fast Fire Ship, Galleon.
- `unit_missing_from_source`: War Hulk.
- `unit_not_resolved_as_trainable_in_final_source_state`: Cannon Galleon, Demo Ship, Fast Fire Ship, Galleon.

## Goths

19 advisor roster units; 18 times calculated; 5 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

- **Goths Team Bonus** (effect 405): production building work rate multiply 1.2; buildings: Barracks; units/candidates: Champion, Condottiero, Elite Huskarl, Halberdier.
- **Perfusion** (effect 513): production building work rate multiply 2; buildings: Barracks; units/candidates: Champion, Condottiero, Elite Huskarl, Halberdier.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Elite Huskarl, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Cheapest alternate-building selections:

- Elite Huskarl: Barracks, 175.00 wood-equivalent, 5.01s.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Elite Huskarl, Trebuchet.
- `source_base_time_differs_from_current_reference`: Elite Huskarl, Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Gurjaras

20 advisor roster units; 19 times calculated; 4 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

- **Gurjaras Team Bonus** (effect 843): unit training time multiply 0.8; buildings: Archery Range, Siege Workshop, Stable; units/candidates: Elite Elephant Archer, Heavy Camel Rider, Siege Elephant.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Hindustanis

19 advisor roster units; 18 times calculated; 4 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Huns

17 advisor roster units; 16 times calculated; 5 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **Huns Team Bonus** (effect 484): production building work rate multiply 1.2; buildings: Stable; units/candidates: Elite Tarkan, Hussar, Paladin.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Elite Tarkan, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Cheapest alternate-building selections:

- Elite Tarkan: Stable, 175.00 wood-equivalent, 15.04s.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Elite Tarkan, Trebuchet.
- `source_base_time_differs_from_current_reference`: Elite Tarkan, Fire Ship, Galleon.
- `unit_missing_from_source`: War Hulk.

## Incas

15 advisor roster units; 12 times calculated; 6 rows flagged. Separately, 23 unit groups resolved from the source, including economic units.

- **C-Bonus, Building Stone cost** (effect 575): building cost multiply 0.85; buildings: Castle; units/candidates: Elite Kamayuk, Petard, Trebuchet.

Source-only candidates (availability needs review): Champion, Condottiero, Elite Eagle Warrior, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Catapult Galleon, Elite Champi Warrior.

## Italians

20 advisor roster units; 18 times calculated; 5 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Cavalry Archer, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Mounted Crossbowman.

## Japanese

18 advisor roster units; 17 times calculated; 4 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Jurchens

20 advisor roster units; 19 times calculated; 5 rows flagged. Separately, 24 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Elite War Chariot, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_availability_needs_review`: Fire Ship, Galleon, Heavy Demo Ship.
- `unit_missing_from_source`: Carrack.
- `unit_not_resolved_as_trainable_in_final_source_state`: Fire Ship, Galleon, Heavy Demo Ship.

## Khitans

20 advisor roster units; 19 times calculated; 6 rows flagged. Separately, 23 unit groups resolved from the source, including economic units.

- **C-Bonus, Skirms Spear Scout train 25% faster** (effect 1011): unit training time multiply 0.8; buildings: Archery Range, Barracks, Stable; units/candidates: Elite Genitour, Elite Skirmisher, Hussar, Pikeman.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Elite War Chariot, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, War Galley.
- `unit_availability_needs_review`: Cannon Galleon, Demo Ship, Fast Fire Ship, War Galley.
- `unit_missing_from_source`: Carrack.
- `unit_not_resolved_as_trainable_in_final_source_state`: Cannon Galleon, Demo Ship, Fast Fire Ship, War Galley.

## Khmer

19 advisor roster units; 18 times calculated; 4 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Koreans

20 advisor roster units; 19 times calculated; 4 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Lithuanians

19 advisor roster units; 18 times calculated; 4 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

- **Lithuanians Team Bonus** (effect 713): production building work rate multiply 1.2; buildings: Monastery; units/candidates: Monk.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: War Hulk.

## Magyars

17 advisor roster units; 16 times calculated; 5 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **Magyars Team Bonus** (effect 6): unit training time multiply 0.8; buildings: Archery Range; units/candidates: Elite Genitour, Heavy Cavalry Archer.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Elite Magyar Huszar, Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Malay

19 advisor roster units; 18 times calculated; 4 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Malians

20 advisor roster units; 19 times calculated; 4 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

- **C-Bonus, buildings cost -15% w** (effect 617): building cost multiply 0.85; buildings: Archery Range, Barracks, Dock, Market, Monastery, Siege Workshop, Stable; units/candidates: Arbalester, Bombard Cannon, Cannon Galleon, Capped Ram, Cavalier, Champion, Condottiero, Elite Genitour, Elite Skirmisher, Fast Fire Ship, Fishing Ship, Hand Cannoneer, Heavy Camel Rider, Heavy Cavalry Archer, Heavy Demo Ship, Light Cavalry, Monk, Pikeman, Scorpion, Siege Onager, Siege Tower, Trade Cart, Trade Cog, Transport Ship, War Galley.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, War Galley.
- `unit_missing_from_source`: Carrack.

## Mapuche

16 advisor roster units; 0 times calculated; 16 rows flagged. Separately, 0 unit groups resolved from the source, including economic units.

Civilization absent from this DAT snapshot.

## Mayans

15 advisor roster units; 13 times calculated; 5 rows flagged. Separately, 22 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Catapult Galleon.

## Mongols

19 advisor roster units; 18 times calculated; 4 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: War Hulk.

## Muisca

16 advisor roster units; 0 times calculated; 16 rows flagged. Separately, 0 unit groups resolved from the source, including economic units.

Civilization absent from this DAT snapshot.

## Persians

20 advisor roster units; 19 times calculated; 4 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Poles

18 advisor roster units; 16 times calculated; 5 rows flagged. Separately, 26 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Heavy Cavalry Archer, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Heavy Mounted Crossbowman.

## Portuguese

19 advisor roster units; 17 times calculated; 5 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Cavalry Archer, Condottiero, Elite Genitour, Fishing Ship, Heavy Demo Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Mounted Crossbowman.

## Romans

17 advisor roster units; 16 times calculated; 5 rows flagged. Separately, 24 unit groups resolved from the source, including economic units.

- **Comitatenses** (effect 895): unit training time multiply 0.666667; buildings: Barracks, Castle, Stable; units/candidates: Cavalier, Elite Centurion, Legionary.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_availability_needs_review`: Demo Ship.
- `unit_missing_from_source`: War Hulk.
- `unit_not_resolved_as_trainable_in_final_source_state`: Demo Ship.

## Saracens

20 advisor roster units; 19 times calculated; 4 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

- **C-Bonus, Market** (effect 354): building cost add -100; buildings: Market; units/candidates: Trade Cart.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Saxons

18 advisor roster units; 0 times calculated; 18 rows flagged. Separately, 0 unit groups resolved from the source, including economic units.

Civilization absent from this DAT snapshot.

## Shu

17 advisor roster units; 16 times calculated; 5 rows flagged. Separately, 21 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Elite War Chariot, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart.

Review boundaries:

- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon, War Chariot.
- `unit_availability_needs_review`: Fire Ship, Galleon, Heavy Demo Ship.
- `unit_missing_from_source`: Carrack.
- `unit_not_resolved_as_trainable_in_final_source_state`: Fire Ship, Galleon, Heavy Demo Ship.

## Sicilians

17 advisor roster units; 15 times calculated; 6 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Cavalry Archer, Condottiero, Elite Genitour, Elite Serjeant, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Cheapest alternate-building selections:

- Elite Serjeant: Donjon, 400.00 wood-equivalent, 9.02s.
- Halberdier: Barracks, 175.00 wood-equivalent, 16.54s.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Elite Serjeant, Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Heavy Mounted Crossbowman.

## Slavs

17 advisor roster units; 16 times calculated; 4 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **Detinets** (effect 481): building cost add -260; buildings: Castle; units/candidates: Elite Boyar, Petard, Trebuchet.
- **Detinets** (effect 481): building cost add 260; buildings: Castle; units/candidates: Elite Boyar, Petard, Trebuchet.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Spanish

19 advisor roster units; 17 times calculated; 5 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Heavy Cavalry Archer, Missionary, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Heavy Mounted Crossbowman.

## Tatars

20 advisor roster units; 19 times calculated; 4 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Teutons

19 advisor roster units; 17 times calculated; 5 rows flagged. Separately, 27 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Cavalry Archer, Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack, Heavy Mounted Crossbowman.

## Tupi

16 advisor roster units; 0 times calculated; 16 rows flagged. Separately, 0 unit groups resolved from the source, including economic units.

Civilization absent from this DAT snapshot.

## Turks

20 advisor roster units; 19 times calculated; 5 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

- **Turks Team Bonus** (effect 410): unit training time multiply 0.8; buildings: Archery Range, Castle, Dock, Siege Workshop; units/candidates: Bombard Cannon, Elite Cannon Galleon, Elite Janissary, Hand Cannoneer.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon, Skirmisher.
- `unit_missing_from_source`: Carrack.

## Varangians

18 advisor roster units; 0 times calculated; 18 rows flagged. Separately, 0 unit groups resolved from the source, including economic units.

Civilization absent from this DAT snapshot.

## Vietnamese

20 advisor roster units; 19 times calculated; 4 rows flagged. Separately, 28 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_missing_from_source`: Carrack.

## Vikings

18 advisor roster units; 14 times calculated; 7 rows flagged. Separately, 25 unit groups resolved from the source, including economic units.

- **Vikings Team Bonus** (effect 411): building cost multiply 0.85; buildings: Dock; units/candidates: Elite Cannon Galleon, Elite Longship, Fire Ship, Fishing Ship, Galleon, Heavy Demo Ship, Trade Cog, Transport Ship.

Source-only candidates (availability needs review): Cavalry Archer, Condottiero, Elite Cannon Galleon, Elite Genitour, Fishing Ship, Heavy Demo Ship, Monk, Petard, Siege Tower, Trade Cart, Trade Cog, Transport Ship, Trebuchet.

Review boundaries:

- `alternate_form_linked_by_DAT_identity_or_transform`: Trebuchet.
- `source_base_time_differs_from_current_reference`: Fire Ship, Galleon.
- `unit_availability_needs_review`: Fire Ship.
- `unit_missing_from_source`: Carrack, Catapult Galleon, Elite Varangian Guard, Mounted Crossbowman.
- `unit_not_resolved_as_trainable_in_final_source_state`: Fire Ship.

## Wei

17 advisor roster units; 16 times calculated; 7 rows flagged. Separately, 21 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Champion, Condottiero, Elite Genitour, Elite War Chariot, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart.

Review boundaries:

- `source_base_time_differs_from_current_reference`: Elite Tiger Cavalry, Fast Fire Ship, Galleon, Xianbei Raider.
- `unit_availability_needs_review`: Demo Ship, Fast Fire Ship, Galleon, Two-Handed Swordsman.
- `unit_missing_from_source`: Carrack.
- `unit_not_resolved_as_trainable_in_final_source_state`: Demo Ship, Fast Fire Ship, Galleon, Two-Handed Swordsman.

## Wu

18 advisor roster units; 17 times calculated; 5 rows flagged. Separately, 22 unit groups resolved from the source, including economic units.

No civilization-specific production-speed or production-building-cost modifiers matched the resolved units or comparison roster in this pass.

Source-only candidates (availability needs review): Condottiero, Elite Genitour, Elite War Chariot, Fishing Ship, Monk, Petard, Siege Tower, Trade Cart.

Review boundaries:

- `source_base_time_differs_from_current_reference`: Fast Fire Ship, Galleon, Jian Swordsman.
- `unit_availability_needs_review`: Fast Fire Ship, Galleon, Heavy Demo Ship.
- `unit_missing_from_source`: Carrack.
- `unit_not_resolved_as_trainable_in_final_source_state`: Fast Fire Ship, Galleon, Heavy Demo Ship.

