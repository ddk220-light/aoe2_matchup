#!/usr/bin/env python3
"""Small, explicit-context research review. Does not modify serving datasets.

These are representative cases, not a complete per-unit upgrade budget. Extra
technology IDs describe already-active bonuses/technologies for each example.
Costs retain source precision; game UI rounding is not inferred.
"""
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/research-review')
SOURCE = Path('/workspace/scratch/production-review/current-raw-source.json')
DATA = json.loads(SOURCE.read_text())
RES = {0: 'food', 1: 'wood', 2: 'stone', 3: 'gold'}


def calculate(civ_name, tech_id, extra, context):
    civ = DATA['civs'][civ_name]
    tech = DATA['techs'][str(tech_id)]
    cost = {r: 0.0 for r in RES.values()}
    for item in tech['resource_costs']:
        if item['type'] in RES and item['flag']:
            cost[RES[item['type']]] += item['amount']
    base = dict(cost)
    tree_path = Path('/workspace/scratch/production-review/current-input/dat/CivTechTrees') / (civ_name.upper() + '.json')
    tree = json.loads(tree_path.read_text())
    available_buildings = {x['Node ID'] for x in tree['civ_techs_buildings'] if x['Node Status'] != 'NotAvailable'}
    raw_locations = [x for x in tech['research_locations'] if x['location_id'] in available_buildings]
    locations = [dict(x) for x in raw_locations]
    assert locations, (civ_name, tech_id)
    work = {x['location_id']: civ['units'][str(x['location_id'])]['work_rate'] for x in locations}
    base_work = dict(work)
    provenance = []
    effects = [(civ['tree_id'], 'civilization', None), (civ['team_id'], 'own_team_bonus', None)]
    effects += [(DATA['techs'][str(i)]['effect_id'], 'already_active_technology', i) for i in extra]
    cost_factor = time_factor = 1.0
    reward_effect = None
    for eid, kind, tid in effects:
        effect = DATA['effects'][str(eid)]
        for index, cmd in enumerate(effect['effect_commands']):
            typ, a, b, c, d = (cmd[k] for k in ['type', 'a', 'b', 'c', 'd'])
            applied = False
            if typ in (101, 103) and a == tech_id:
                assert c in (-1, 0, 1, 2), cmd
                def op(v):
                    return d if c == 0 else v * d if c == 2 else v + d
                if typ == 101:
                    for rid, name in RES.items():
                        if b in (-1, rid):
                            cost[name] = op(cost[name])
                else:
                    for location in locations:
                        location['research_time'] = op(location['research_time'])
                applied = True
            elif typ in (1, 6) and a in (85, 86, 269):
                def resource_op(v):
                    return v * d if typ == 6 else d if b == 0 else v + d
                if a == 85:
                    cost_factor = resource_op(cost_factor)
                elif a == 86:
                    time_factor = resource_op(time_factor)
                else:
                    reward_effect = int(d)
                applied = True
            elif typ in (0, 4, 5, 10, 14, 15) and c == 13:
                for bid in work:
                    unit = civ['units'][str(bid)]
                    if a == bid or (a == -1 and b == unit['class_id']):
                        work[bid] = d if typ in (0, 10) else work[bid] + d if typ in (4, 14) else work[bid] * d
                        applied = True
            if applied:
                provenance.append({'source_kind': kind, 'tech_id': tid, 'effect_id': eid,
                                   'effect_name': effect['name'], 'command_index': index, 'command': cmd})
    cost = {r: value * cost_factor for r, value in cost.items()}
    reward = {r: 0.0 for r in RES.values()}
    if reward_effect is not None:
        effect = DATA['effects'][str(reward_effect)]
        for index, cmd in enumerate(effect['effect_commands']):
            assert cmd['type'] == 1 and cmd['b'] == 1 and cmd['a'] in RES, cmd
            reward[RES[cmd['a']]] += cmd['d']
            provenance.append({'source_kind': 'research_completion_reward', 'tech_id': None,
                               'effect_id': reward_effect, 'effect_name': effect['name'],
                               'command_index': index, 'command': cmd})
    final_locations = []
    for raw, location in zip(raw_locations, locations):
        bid = location['location_id']
        final_locations.append({'building_id': bid, 'base_seconds': raw['research_time'],
                                'modified_seconds_before_building': location['research_time'],
                                'base_building_work_rate': base_work[bid], 'building_work_rate': work[bid],
                                'global_duration_factor': time_factor,
                                'final_seconds': location['research_time'] * time_factor / work[bid]})
    return {'civilization': civ_name, 'tech_id': tech_id, 'technology': tech['name'],
            'context': context, 'already_active_tech_ids': extra, 'base_cost': base,
            'upfront_cost_unrounded': cost, 'completion_reward': reward,
            'net_cost_unrounded': {r: cost[r] - reward[r] for r in cost},
            'free': all(v == 0 for v in cost.values()),
            'zero_research_time': all(x['final_seconds'] == 0 for x in final_locations),
            'research_locations': final_locations, 'applied': provenance}


cases = [
    ('Spanish', 75, [186], 'Imperial; ordinary paid research; no allied bonuses'),
    ('Burgundians', 265, [], 'Imperial; Cavalier already researched; own bonuses'),
    ('Chinese', 237, [304, 350, 351, 352], 'Arbalester purchased in Imperial; unrounded costs'),
    ('Portuguese', 75, [], 'Imperial; own team research-duration bonus'),
    ('Bulgarians', 75, [], 'Imperial; own team Blacksmith work-rate bonus'),
    ('Vietnamese', 315, [], 'Imperial; free zero-time Conscription'),
    ('Vietnamese', 213, [], 'Feudal or later; economic discount and speed bonus'),
    ('Franks', 14, [], 'Feudal or later; farm upgrade granted when prerequisites met'),
    ('Goths', 22, [343], 'Town Center built; Loom bonus active'),
    ('Bohemians', 45, [785], 'Hussite Reforms already completed; its own cost is excluded here'),
]
rows = [calculate(*case) for case in cases]
spanish_attack_chain = [calculate('Spanish', tid, [186], 'Purchased at its normal age; ordinary research; earlier tiers included') for tid in [67, 68, 75]]
chain_totals = {field: {resource: sum(row[field][resource] for row in spanish_attack_chain) for resource in RES.values()}
                for field in ['base_cost', 'upfront_cost_unrounded', 'completion_reward', 'net_cost_unrounded']}
assert chain_totals['upfront_cost_unrounded']['food'] == 645
assert chain_totals['completion_reward']['gold'] == 60
# Check the requested mechanics independently against hand-calculated examples.
by_civ = {r['civilization']: r for r in rows}
assert by_civ['Spanish']['upfront_cost_unrounded']['gold'] == 0
assert by_civ['Spanish']['completion_reward']['gold'] == 20
assert by_civ['Burgundians']['upfront_cost_unrounded'] == dict(food=650, wood=0, stone=0, gold=375)
assert abs(by_civ['Portuguese']['research_locations'][0]['final_seconds'] - 80) < 1e-4
assert abs(by_civ['Bulgarians']['research_locations'][0]['final_seconds'] - 100 / 1.8) < 1e-4
assert by_civ['Franks']['free'] and by_civ['Franks']['zero_research_time']
assert not by_civ['Goths']['free'] and by_civ['Goths']['research_locations'][0]['final_seconds'] == 1
assert by_civ['Bohemians']['upfront_cost_unrounded'] == dict(food=1300, wood=0, stone=0, gold=0)
assert all(v >= 0 for row in rows for v in row['upfront_cost_unrounded'].values())

age_exclusions = []
for tid in [323, 324, 326]:
    tech = DATA['techs'][str(tid)]
    age_exclusions.append({'tech_id': tid, 'definition': tech, 'effect': DATA['effects'][str(tech['effect_id'])]})
payload = {'source': DATA['source'], 'extract_cache_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
           'scope': 'Ten representative, explicitly contextualized research examples; not a full per-unit ledger',
           'limits': ['Research costs preserve source float precision; UI rounding unverified.',
                      'A single technology duration is not the elapsed time to fully upgrade a unit.',
                      'Shared upgrade/prerequisite allocation and all-civilization coverage are future work.',
                      'Reward examples cover ordinary paid Spanish research; age-advance exclusions are recorded separately.'],
           'examples': rows, 'spanish_melee_attack_chain': {'technologies': spanish_attack_chain, 'totals': chain_totals,
              'scope': 'Forging + Iron Casting + Blast Furnace only, not the complete upgrade bill for a unit'},
           'spanish_age_reward_exclusions': age_exclusions}
(ROOT / 'research-examples.json').write_text(json.dumps(payload, indent=2) + '\n')
with (ROOT / 'research-examples.csv').open('w') as stream:
    fields = ['civilization', 'tech_id', 'technology', 'context', 'base_cost', 'upfront_cost_unrounded',
              'completion_reward', 'net_cost_unrounded', 'free', 'zero_research_time', 'research_locations']
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for row in rows:
        writer.writerow({k: json.dumps(row[k]) if isinstance(row[k], (dict, list)) else row[k] for k in fields})
print(json.dumps([{k: r[k] for k in ['civilization', 'technology', 'upfront_cost_unrounded', 'completion_reward', 'research_locations']} for r in rows], indent=2))
