# Military upgrade review database

Source: the user-supplied empires2_x2_p1.dat and matching CivTechTrees JSON files.
The manifest records the source checksum and paths. The accepted production
review supplies the resolved availability snapshot and comparison roster.

All upgrade costs use Imperial modifiers, including earlier-tier upgrades.
Food, wood, stone and gold are separate. Upfront cost, completion reward and net
cost are separate. Fractional calculations are retained; integer UI rounding
has not been inferred. Spanish rewards follow the DAT reward-effect pointer.

## Tables and views

- units: military units by civilization, including the entire advisor roster.
- civilization_upgrades: all available research definitions and final prices.
  Economic definitions remain reference-only; they are not associated to units.
- unit_upgrades: one row per unit/technology, direct or production_support.
- unit_upgrade_data: readable joined view, including selected building cost.
- unit_upgrade_totals: resource totals by unit and scope.
- research_locations: every available research route and per-route duration.
- buildings: base/final construction costs and exact modifier provenance.
- unit_research_buildings / unit_building_totals: distinct selected buildings;
  one building is charged once even if many upgrades use it. Automatic free
  upgrades retain their nominal research building but do not charge a queue.
- unit_building_workloads: research seconds grouped by building and scope.
- tech_prerequisites: original gate IDs, required count and availability.
- unit_upgrade_candidates: unresolved player-resource or special-effect scope;
  these are review candidates, not silently charged to the unit.
- raw_technologies / raw_effects: source definitions for auditing.

Direct associations follow final-unit/class attributes, projectile effects,
living alternate forms, unit-tier/unlock effects and research prerequisites.
Non-trainable combat forms upgraded by the same tier technology are linked with
an explicit inference flag and raw command evidence (including dismounted Konnik).
Unit cost changes are direct; production-only changes are a separate scope.
Civilian economy units are excluded. Packed/deployed aliases can have separate
rows when needed to retain all advisor identities; do not sum unit rows together.

Research time is an independent post-Imperial building workload. Available
work-rate upgrades apply except the target research's own dependent effects.
Paid speed modifiers and a duration without paid work-rate bonuses are recorded.
This is not an elapsed build order: queues can overlap and prerequisites/order
matter. All available modifiers are assumed active; their conditions remain
visible, even when an economic/production support technology is outside the
direct military upgrade package.

Standalone research routes use the cheapest building by wood + 2*stone, then
fastest time. Per-unit selections minimize the combined construction cost and
reuse already-required buildings: a Castle needed for Stirrups also handles the
Elite Konnik upgrade, avoiding an unnecessary Krepost charge. All alternatives
are retained. unit_all_building_totals deduplicates across both scopes as well.
Costs are construction costs, excluding age-up
fees, construction time and other buildings needed to unlock construction.
Population-dependent research prices retain the base component and are flagged;
totals with all_costs_fixed=0 require a scenario input before use as a final bill.

Comparison: join two unit_upgrades sets on tech_id for common upgrades. Compare
their cost and time rows; retain left-only and right-only upgrades separately.
Free upgrades stay in those sets. Never normalize by army size or rank with an
arbitrary threshold. Compare the direct and production_support scopes separately.

See validation.json for source-backed regression checks and coverage. This is a
review artifact; unresolved candidates should be reviewed before advisor use.

## Rebuild and compare

Run tools/build_upgrade_review.py in the advisor worktree. The CLI accepts raw
extraction, same-install trees, production review and unit-link cache paths.
Use --extract-links with the genieutils virtualenv to regenerate unit links from
the DAT. Run tools/compare_unit_upgrades.py Spanish:567 Goths:567 to obtain common
upgrade costs/times and separate one-sided upgrade bills. Technology IDs, rather
than localized names, define the intersection. comparison-example.json shows it.
